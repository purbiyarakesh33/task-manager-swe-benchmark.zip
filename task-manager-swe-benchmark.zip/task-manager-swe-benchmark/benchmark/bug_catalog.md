# Hidden Bug Catalog

This file is for the benchmark operator. Do not give it to the SWE agent.

Each bug is designed to be injected into the clean repository. Prefer changing one or two lines rather than adding an obvious marker.

## BUG-001 — Broken active filter

**Difficulty:** Easy

**Inject into:** `src/task_manager/repository.py`

Change the status filter so that it selects tasks whose status is NOT the requested status.

**Expected behavior:**  
`list(TaskStatus.ACTIVE)` returns only active tasks.

**Primary regression test:**  
`tests/test_repository.py::test_repository_filters_by_status`

**Root cause location:** Repository filtering predicate.

---

## BUG-002 — Partial update destroys description

**Difficulty:** Medium

**Inject into:** `src/task_manager/service.py`

Change `update_task()` so that when a title is supplied, the existing description is replaced with an empty string.

**Expected behavior:**  
A PATCH containing only `title` must preserve the existing description.

**Primary regression test:**  
`tests/test_service.py::test_update_is_partial_and_preserves_other_fields`

**Root cause location:** Service-layer partial update logic.

---

## BUG-003 — Completion changes the title

**Difficulty:** Medium

**Inject into:** `src/task_manager/service.py`

Introduce a defect where `complete_task()` modifies the task title while changing the status.

**Expected behavior:**  
Completing a task changes status and timestamp only.

**Primary regression test:**  
`tests/test_service.py::test_complete_task_changes_only_status_and_timestamp`

**Root cause location:** Service-layer state transition.

---

## BUG-004 — API filtering ignores query parameter

**Difficulty:** Medium

**Inject into:** `src/task_manager/api.py`

Make `list_tasks()` call the service without forwarding the `status` query parameter.

**Expected behavior:**  
`GET /tasks?status=active` must return only active tasks.

**Primary regression test:**  
`tests/test_api.py::test_complete_then_filter_active`

**Root cause location:** API-to-service parameter propagation.

---

## BUG-005 — Title normalization accepts empty input

**Difficulty:** Medium

**Inject into:** `src/task_manager/validators.py`

Move or remove the empty-title check so that whitespace-only titles are accepted.

**Expected behavior:**  
Whitespace-only titles must raise `ValueError`.

**Primary regression test:**  
`tests/test_validators.py::test_empty_title_is_rejected`

**Root cause location:** Validation boundary.

---

## BUG-006 — Repository returns mutable internal state

**Difficulty:** Hard

**Inject into:** `src/task_manager/repository.py`

Remove the defensive copy from `get()`.

**Expected behavior:**  
Changing an object returned by `get()` must not mutate persisted repository state until `update()` is called.

**Primary regression test:**  
`tests/test_repository.py::test_repository_returns_copies`

**Root cause location:** Repository encapsulation / object ownership.

---

## BUG-007 — ID collision after deletion

**Difficulty:** Hard

**Inject into:** `src/task_manager/repository.py`

Change ID allocation so that after deleting a task, a later create can reuse an existing ID.

**Expected behavior:**  
IDs are monotonically allocated and must never collide with an existing task.

**Recommended additional test:**  
Create task 1, create task 2, delete task 1, create task 3. The third task must have ID 3.

**Root cause location:** ID allocation lifecycle.

---

## BUG-008 — Timestamp regression

**Difficulty:** Hard

**Inject into:** `src/task_manager/service.py`

Make an update operation set `updated_at` to a timestamp older than the task's previous `updated_at`.

**Expected behavior:**  
Every successful update should have an `updated_at` timestamp no earlier than the previous timestamp.

**Primary regression test:**  
`tests/test_service.py::test_complete_task_changes_only_status_and_timestamp`

**Root cause location:** Service timestamp handling.

---

## BUG-009 — Wrong HTTP error mapping

**Difficulty:** Hard

**Inject into:** `src/task_manager/api.py`

Make a missing task during PATCH return HTTP 400 instead of HTTP 404.

**Expected behavior:**  
Missing resources must return 404.

**Recommended additional test:**  
`PATCH /tasks/999` should return 404.

**Root cause location:** API exception mapping.

---

## BUG-010 — Cross-layer bug

**Difficulty:** Hard

**Inject into:** `src/task_manager/api.py` and/or `src/task_manager/service.py`

Create a defect where the API accepts `status=completed`, but the status value is lost or replaced before reaching the repository.

**Expected behavior:**  
`GET /tasks?status=completed` returns exactly the completed tasks.

**Recommended test:**  
Create two tasks, complete one, request `status=completed`, and assert that only the completed task is returned.

**Root cause location:** Requires tracing API -> service -> repository.

---

# Scoring suggestion

For each bug record:

- Reproduced failure: 1 point
- Correct root cause: 2 points
- Minimal correct fix: 2 points
- Existing tests pass: 2 points
- Added a useful regression test: 2 points
- No unrelated changes: 1 point

Total: 10 points per task.

Do not judge an agent solely by whether it eventually makes the test suite green. A benchmark should distinguish a correct diagnosis from a broad or brittle patch.
