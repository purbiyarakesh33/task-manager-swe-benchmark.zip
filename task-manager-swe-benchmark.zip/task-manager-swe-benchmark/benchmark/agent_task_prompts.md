# Generic prompts

These are intentionally vague. Give the SWE agent one prompt and the bugged repository.

## Basic

There is a bug in this repository. Find it, fix it, and run the tests.

## Slightly stronger

Something is broken in this repository. Reproduce the problem, identify the root cause, make the smallest correct fix, and verify the test suite.

## Realistic issue

The repository is failing one or more expected behaviors. Investigate the codebase and tests, determine the root cause, implement a robust fix without changing unrelated behavior, and run the full test suite.

## Strict benchmark

Find and fix the bug in this repository. Do not ask me for the location of the bug. Reproduce the failure yourself, trace the relevant code path, make the minimal production-code change required, and run all tests before finishing. Summarize the root cause and files changed.
